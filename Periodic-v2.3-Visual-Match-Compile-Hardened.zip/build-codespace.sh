#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

log() { printf '\n=== %s ===\n' "$1"; }

log "Checking Java 17"
JAVA17=""
for candidate in \
  /usr/lib/jvm/java-17-openjdk-amd64 \
  /usr/lib/jvm/temurin-17-jdk-amd64 \
  /opt/java/17 \
  "${JAVA_HOME:-}"; do
  if [ -n "$candidate" ] && [ -x "$candidate/bin/java" ]; then
    major="$("$candidate/bin/java" -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
    if [ "$major" = "17" ]; then JAVA17="$candidate"; break; fi
  fi
done

if [ -z "$JAVA17" ]; then
  if command -v sudo >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y openjdk-17-jdk
    JAVA17=/usr/lib/jvm/java-17-openjdk-amd64
  else
    echo "ERROR: Java 17 is unavailable and cannot be installed automatically." >&2
    exit 1
  fi
fi

export JAVA_HOME="$JAVA17"
export PATH="$JAVA_HOME/bin:$PATH"
java -version

log "Checking Android SDK"
SDK=""
for candidate in \
  "${ANDROID_SDK_ROOT:-}" \
  "${ANDROID_HOME:-}" \
  "$HOME/Android/Sdk" \
  "$HOME/android-sdk" \
  "/usr/local/lib/android/sdk" \
  "/opt/android-sdk"; do
  if [ -n "$candidate" ] && [ -d "$candidate" ]; then SDK="$candidate"; break; fi
done

find_sdkmanager() {
  find "$1" -type f -name sdkmanager 2>/dev/null | head -n 1
}

SDKMANAGER=""
if [ -n "$SDK" ]; then SDKMANAGER="$(find_sdkmanager "$SDK")"; fi

if [ -z "$SDKMANAGER" ]; then
  if command -v sudo >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
      google-android-cmdline-tools-13.0-installer \
      android-sdk-platform-tools \
      unzip curl
    for candidate in /usr/lib/android-sdk "$HOME/android-sdk" /opt/android-sdk; do
      if [ -d "$candidate" ]; then
        found="$(find_sdkmanager "$candidate")"
        if [ -n "$found" ]; then SDK="$candidate"; SDKMANAGER="$found"; break; fi
      fi
    done
  fi
fi

if [ -z "$SDKMANAGER" ]; then
  echo "ERROR: Android sdkmanager was not found. Install Android command-line tools, then rerun." >&2
  exit 1
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$(dirname "$SDKMANAGER"):$ANDROID_HOME/platform-tools:$PATH"
yes | "$SDKMANAGER" --licenses >/dev/null || true
"$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties

log "Validating source"
python3 tools/validate_source.py

log "Building debug APK"
chmod +x gradlew
./gradlew --no-daemon clean assembleDebug --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "ERROR: Gradle completed without producing $APK" >&2
  exit 1
fi

cp "$APK" "Periodic-v2.3-debug.apk"

log "Running unit tests and Android lint"
./gradlew --no-daemon testDebugUnitTest lintDebug --stacktrace

log "Build successful"
echo "APK: $(pwd)/Periodic-v2.3-debug.apk"
